// COSC 2030
// Lab 3
// @date 10-8-18
// @author Tamara Linse

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>

using namespace std;

int main()
{
	/*
	short n = 0, sum = 0;
	char s = ' '; 
	while (s != 'y')
	{
		cout << "Input n: ";
		cin >> n;
		for (short i = 1; i <= n; i++)
		{
			sum += i;
		}
		cout << "n = " << n << endl;
		cout << "sum = " << sum << endl;
		cout << "Would you like to end? ";
		cin >> s;
		cout << endl;
	}

	long n = 0, sum = 0;
	char s = ' ';
	while (s != 'y')
	{
		cout << "Input n: ";
		cin >> n;
		for (long i = 1; i <= n; i++)
		{
			sum += i;
		}
		cout << "n = " << n << endl;
		cout << "sum = " << sum << endl;
		cout << "Would you like to end? ";
		cin >> s;
		cout << endl;
	}

	long n = 0;
	float prod = 1;
	char s = ' ';
	while (s != 'y')
	{
		cout << "Input n: ";
		cin >> n;
		for (int i = 1; i <= n; i++)
		{
			prod *= i;
		}
		cout << "n = " << n << endl;
		cout << "factorial = " << prod << endl;
		cout << "Would you like to end? ";
		cin >> s;
		cout << endl;
	}

	long n = 0;
	double prod = 1;
	char s = ' ';
	while (s != 'y')
	{
		cout << "Input n: ";
		cin >> n;
		for (int i = 1; i <= n; i++)
		{
			prod *= i;
		}
		cout << "n = " << n << endl;
		cout << "factorial = " << prod << endl;
		cout << "Would you like to end? ";
		cin >> s;
		cout << endl;
	}

	float n = 0;
	float sum = 0;
	char s = ' ';
	while (s != 'y')
	{
		cout << "Input n: ";
		cin >> n;
		float num = 1 / n;
		for (float i = 1; i <= n; i++)
		{
			sum += num;
		}
		cout << "n = " << n << endl;
		cout << "sum = " << sum << endl;
		cout << "Would you like to end? ";
		cin >> s;
		cout << endl;
	}
	*/

	for (double i = 3.4; i < 4.4; i += 0.2)
	{
		cout << "i = " << i << endl;
	}

	system("pause");
	return 0;
}